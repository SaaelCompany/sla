---
name: Jira installation target
description: The reported Jira and Universal Plugin Manager versions for this plugin.
---

The reported installation target is Jira Core 8.21.1, Jira Service Management 4.21.1, and Universal Plugin Manager 5.1.2.

**Why:** the user identified this exact environment while reporting that the plugin JAR would not install.

**How to apply:** preserve these version constraints when changing plugin metadata or dependencies. A successful Maven build is not proof that the plugin has installed on this Jira instance.