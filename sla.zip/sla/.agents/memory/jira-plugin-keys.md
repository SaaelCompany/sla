---
name: Jira plugin module keys
description: Atlassian plugin descriptor module keys are unique across module types.
---

Do not reuse a `key` between Jira plugin modules, even when the XML elements have different types (for example, `servlet` and `web-resource`).

**Why:** Jira rejected Portal SLA with `PluginParseException: Found duplicate key` when a servlet and web-resource shared a key.

**How to apply:** check all module key declarations in `atlassian-plugin.xml` when adding or renaming modules; resource URL references should continue using the intended web-resource key.