---
name: Portal SLA's core scope
description: The user's intended default experience for the Jira plugin.
---

The primary need is a compact SLA list on each customer request page, showing remaining time and a pause icon when relevant. The visual layout editor and alternate variants are optional.

**Why:** the user said the plugin was too complex and asked only for SLA visibility on customer requests, matching their screenshot.

**How to apply:** keep the simple compact customer-visible SLA list working without requiring the project editor; preserve custom layout tools as optional unless the user asks to remove them.